﻿using UnityEngine;
using System.Collections;

public struct Finger
{
	public float x;
	public float y;
}
