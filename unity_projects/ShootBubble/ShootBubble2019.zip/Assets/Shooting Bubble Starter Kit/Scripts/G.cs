﻿using UnityEngine;
using System.Collections;

public class G
{
	public static float width 	= 480.0f;
	public static float height 	= 800.0f;
	
	public static float radius 	= 54.0f / 2.0f;
	public static int 	rows	= 15;
	public static int	cols	= 8;
	
	public static int	rowsInData = 10;
	public static int	colsInData = 8;
	
	public static float shootingMinAngle = 15.0f;
	public static float shootingMaxAngle = 165.0f;
	
	public static float bubbleSpeed = 20.0f;
}
